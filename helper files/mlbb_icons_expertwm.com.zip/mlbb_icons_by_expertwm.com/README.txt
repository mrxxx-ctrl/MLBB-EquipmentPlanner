
                                 _                                                 
   ___ __  __ _ __    ___  _ __ | |_ __      __ _ __ ___      ___  ___   _ __ ___  
  / _ \\ \/ /| '_ \  / _ \| '__|| __|\ \ /\ / /| '_ ` _ \    / __|/ _ \ | '_ ` _ \ 
 |  __/ >  < | |_) ||  __/| |   | |_  \ V  V / | | | | | | _| (__| (_) || | | | | |
  \___|/_/\_\| .__/  \___||_|    \__|  \_/\_/  |_| |_| |_|(_)\___|\___/ |_| |_| |_|
             |_|                                                                   

____________________________________________________________________________________________


	LAST UPDATED:		2020/02/11
	
	PATCH:				1.4.50
	
	ICON SIZE:			128x128px
	
	AVAILABLE:			emblems
						heroes
						items
						misc
						ranks
						roles
						spells
						talents

	WEBSITE:			https://www.expertwm.com/
	
	FACEBOOK:			https://www.facebook.com/expertwm
	
	INSTAGRAM:			https://www.instagram.com/expertwman
	
	CONTACT US:			info@expertwm.com
	
	CHANGE LOG:			2020/02/11	Added Cecilion
						2020/01/17	Added Carmilla
						2020/01/14	Updated to Patch 1.4.44
						2019/12/17	Updated to Patch 1.4.36
						2019/11/26	Added Wanwan
						2019/11/04	Updated to Patch 1.4.22
						2019/09/22	Updated to Patch 1.4.14
						2019/07/23	Updated to Patch 1.3.96
						2019/06/25	Updated to Patch 1.3.88
						2019/06/04	Updated to Patch 1.3.80
						2019/04/23	Updated to Patch 1.3.68
						2019/03/19	Updated to Patch 1.3.60
						2019/03/12	Added Khufra
						2019/02/21	Updated to Patch 1.3.52
						2019/01/16	Updated to Patch 1.3.44
						2018/12/18	Updated to Patch 1.3.36
						2018/12/14	Updated to Patch 1.3.32, added "misc" category
						2018/11/20	Updated to Patch 1.3.30, added Minsitthar
						2018/09/21	Updated to Patch 1.3.14, added Harith and Kimmy
						2018/07/26	Added Lunox and Belerick
						2018/07/23	Added Vale and Leomord
						2018/07/11	Added Selena, Aldous and Claude
						2018/06/30	Updated to patch 1.2.88
						2018/06/14	Added Chang'e
						2018/06/19	Added Kaja

____________________________________________________________________________________________